import numpy as np


class Normalization:
    def normalize_x(self, x_vector: np.ndarray):
        pass

    def denormalize_x(self, x_vector: np.ndarray):
        pass

    def normalize_y(self, y_vector: np.ndarray):
        pass

    def denormalize_y(self, y_vector: np.ndarray):
        pass
