import enum


class FitterType(enum.Enum):
    GRADIENT = 0,
    NON_GRADIENT = 1
